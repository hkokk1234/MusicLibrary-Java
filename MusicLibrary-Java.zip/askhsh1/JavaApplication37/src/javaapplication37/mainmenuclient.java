//icsd22077
//Zacharias Kokkinakis


package javaapplication37;

import javax.swing.*;
import java.awt.*;
import java.io.*; 
import java.net.Socket;

public class mainmenuclient {
    //dhlwsh metavlhtwn ths diefthinshs kai ths thyras diakosmiti
    private static final String address="127.0.0.1";
    private static final int port=888;

   //methodos pou elegxei an o diakosmiths einai diathesimos na syndethei
    private static boolean elegxossyndeshs() {
        try (Socket socket = new Socket(address, port)){
            //epityxhs syndesh
            return true;
        }             //adynamia syndeshs me ton server 

        catch (IOException e) {
            return false;
        }
    }
    
    public static void main(String[] args) {
//dhmiourgia parathyrou kai megethous ths efarmoghs
        JFrame frame=new JFrame("Music library");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLayout(new BorderLayout());
//dhmiourgia etiketas titlou
        JLabel epikefalida=new JLabel("Music library management system", SwingConstants.CENTER);
        epikefalida.setFont(new Font("Arial", Font.BOLD, 18));
        epikefalida.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
//dhmiourgia koumpiwn album kai mousikhs
        JButton album=new JButton("Album");
        JButton mousiki=new JButton("Music");
//orismos megethous twn koumpiwn
        album.setPreferredSize(new Dimension(120, 40));
        mousiki.setPreferredSize(new Dimension(120, 40));

//prosthiki leitourgias koumpiou music
album.addActionListener(e->{
    //elegxos diathesimou diakosmiti
            if(elegxossyndeshs()){
                //ekkinhsh parathyrou album efoson yphrxe epityxhs syndesh ston diakosmiti
                new albumclient();
            }else{
                //emfanhsh mhnymatos se periptwsh poy yparxei adynamia syndeshs me ton server 
                JOptionPane.showMessageDialog(frame, "server is not available.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        });
//prosthiki koumpiou album
        mousiki.addActionListener(e -> {
            if(elegxossyndeshs()){
                //ekkinhsh parathyrou dhlwshs stoixeiwn mousikhs
                new clientmusic();
            }else{
                JOptionPane.showMessageDialog(frame, "server is not available.", "Connection Error", JOptionPane.ERROR_MESSAGE);
            }
        });
//dhmiourgia panel gia topothetisi koumpiwn         
        JPanel pinakasstoixeiwn = new JPanel();
        pinakasstoixeiwn.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 15));
        pinakasstoixeiwn.add(album);
        pinakasstoixeiwn.add(mousiki);
 //prosthiki stoixeiwn sto kyrio parathyro                                                                                                                                                                                                                                                                                            
        frame.add(epikefalida, BorderLayout.NORTH);
        frame.add(pinakasstoixeiwn, BorderLayout.CENTER);
 //emfanhsh parathyrou
        frame.setVisible(true);
    }
}
