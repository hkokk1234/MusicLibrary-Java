
//icsd22077
//Zacharias Kokkinakis

package javaapplication37;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;

public class server {
    //thyra pou akouei o server
    private static final int port = 888;
//map gia ta albums me pinaka me ta ypoloipa stoixeia pou einai sth domh tou album
    private static Map<String, String[]> albums = new HashMap<>();
    //set me olou tous titlous tragoudiwn pou vriskontai sth domh twn tragoudiwn
    private static Set<String> tragoudi=new HashSet<>();

    public static void main(String[] args) {
        System.out.println("Server started on port " + port);
        new mainmenuclient();
//prospatheia epikoinwnias me ton client
        try (ServerSocket serverSocket = new ServerSocket(port)) {
            while (true) {
                //anamonh syndeshs me ton client
                try (Socket socket = serverSocket.accept();
                     ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
                     ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

                    Object input = in.readObject();
                    if (!(input instanceof String))
                        continue;

                    String request=(String) input;
                    String response="";
// synthiki gia eisagwgh neou tragoudiou ypovallontas ta stoixeia tou 
                   if (request.startsWith("ADD SONG:")) {
                        String[] elem=request.split(":", 4);
                        if (elem.length == 4){
                            String titlosmusikhs = elem[1].trim();
                            //synthikh an to tragoudi me idio titlo yparxei
                            if (tragoudi.contains(titlosmusikhs)) {
                                response = "music exists!";
                            } else {
                                //prosthiki tragoudiou sth periptwsh pou o titlos einai monadikos
                                tragoudi.add(titlosmusikhs);
                                response = "music added!";
                            }
                        } else {
                            response = "invalid song format!";
                        }

                    } //synthikh ananewsh stoixeiwn hdh dhlwmenou tragoudiou
                   else if (request.startsWith("UPDATE SONG:")) {
                       //diaxwrismos song_update,palio titlos,neos, titlos
                        String[] parts=request.split(":", 3);
                        if (parts.length==3) {
                            //palios titlos
                            String ftitle = parts[1].trim();
                            //neos titlos
                            String ltitle = parts[2].trim();
                            if (tragoudi.remove(ftitle)) {
                                //an yparxei palio tragoudi to afairei
                                //prosthesh neou tragoudiou
                                tragoudi.add(ltitle);
                                response="Song updated !!!";
                            } else {
                                response = "Song not found.";
                            }
                        } else {
                            response = "Invalid update request!";
                        }

                    } 
                   //synthikh gia thn diagrafh tou tragoudiou
                   else if (request.startsWith("DELETE SONG:")) {
                        String titlos = request.substring(12).trim();
                        //an to tragoudi yparxei diagrafetai
                        if (tragoudi.remove(titlos)) {
                            response = "Song deleted !!";
                        } else //se periptwsh pou de vrethei to tragoudi
                        {
                            response = "Song not found!";
                        }

                    } else if (request.equals("GETSONGS")) {
                        //apostolh tragoudiwn
                        out.writeObject(new ArrayList<>(tragoudi));
                        continue;

                    } 
                    //synthikes gia thn eisagwgh album apo ton client
                    else if (request.startsWith("ADD ALBUM:")) {
                        //diaxwrismos aithmatos se 6 merh add_album,titlos,perigrafh,eidos mousikhs,xronia,tragoudi
                        String[] parts = request.split(":", 6);
                        if (parts.length==6) {
                            //titlos album
                            String title = parts[1];
                            //synthikh se periptwsh pou yparxei to album me ton idio titlo
                            if (albums.containsKey(title)) {
                                response="album  exists!";
                            } else
                            {
                                //synthikh se periptwsh pou o titlos tou album einai monadikos
                                //prostithetai to album me ta stoixeia sth domh
                                String[] details = Arrays.copyOfRange(parts, 2, 6);
                                albums.put(title, details);
                                response = "album added !!";
                            }
                        } else {
                            //synthikh se periptwsh pou den mporei na diavastei kapoio stoixeio pou dhlwse o client
                            response = "Invalid ADD_ALBUM format.";
                        }

                    }//synthikes gia thn ananewsh stoixeiwn album apo ton client
                    else if (request.startsWith("UPDATE ALBUM:")) {
                     //diaxwrismos paliou,neou titlou,perigrafh,eidos,tragoudi
                        String[] parts = request.split(":", 7);
                        if (parts.length == 7) {
                            //metavlhth pou prosdiorizei palio titlo
                            String ftitle=parts[1];
                            //metavlhth pou prosdiorizei to stoixeio me neo titlo
                            String ltitle=parts[2];
                            String[] elem = Arrays.copyOfRange(parts, 3, 7);

                            if (albums.containsKey(ftitle)) {
                                //an yparxei album me palio titlo o palios titlos diagrafetai
                                albums.remove(ftitle);
                                //dhlwsh tou neou titlou kai stoixeiwn
                                albums.put(ltitle, elem);
                                response="Album updated successfully!";
                            } else {
//adynamia evreshs album
                                response="Album not found.";
                            }
                        } else {
                            response="Invalid UPDATE_ALBUM format.";
                        }

                    }//synthikes gia th diagrafh enos album apo thn domh apo ton client  
                    else if (request.startsWith("DELETE ALBUM:")) {
                        String titlosmusikhs = request.substring(13).trim();
                       
                     
                        //an yparxei to album diagrafetai
                           if (albums.remove(titlosmusikhs) != null) {
                            response = "Album deleted !!";
                        } else//an den yparxei to album
                        {
                            
                            response = "Album not found.";
                        }

                    }
                    //synthikh anazhthshs onomatos album pou prostethike sth domh apo ton client
                    else if (request.startsWith("SEARCH ALBUM:")) {
                        //elegxos an to aithma pou lhfthike einai entolh gia anazththsh album
                        String titlos = request.substring(13).trim();
                        if (albums.containsKey(titlos)) {
                           //elegxos an to album yparxei
                           //stoixeia pou exoun apothikeftei me ton sygkekrimeno titlo pou anazhthse o client
                            String[] stoixeio = albums.get(titlos);
                            response ="title: "+ titlos+" "
                                    +"description: "+stoixeio[0]+"  "
                                    +"type: "+stoixeio[1]+" "
                                    +"year: "+stoixeio[2]+" "
                                    +"song: "+stoixeio[3];
                            //dhmiourgia symboloseiras pou perilambanei ta dedomena tou album
                        } else {
                            response="Album not found.";
                        }

                    }
                    
                    //entolh mh symbath gia epikoinwnia client-server
                    else {
                        response = "unknown";
                    }
//apostolh apanthshs ston client 
                    out.writeObject(response);
                    out.flush();

                } catch (Exception e) {
                    //adynamia syndeshs me client
                    System.err.println("client error "+e.getMessage());
                }
            }
        } catch (IOException e) {
            //adynamia ekkinishs server
            System.err.println("server couldn't start"+port);
        }
    }
}
