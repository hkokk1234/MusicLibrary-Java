//icsd22077
//Zacharias Kokkinakis

package javaapplication37;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

public class albumclient {
    private static final String address = "127.0.0.1";
    private static final int port = 888;

    private DefaultListModel<String> albumlist = new DefaultListModel<>();
    private JList<String> listaalbum = new JList<>(albumlist);
    private JTextField titlos = new JTextField();
    private JTextField perigrafh = new JTextField();
    private JTextField eidos = new JTextField();
    private JTextField etos = new JTextField();
    private JComboBox<String> epiloghtragoudiou = new JComboBox<>();
    private HashMap<String, String[]> albuminfo = new HashMap<>();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(albumclient::new);
    }
//constructor arxikopoihsh gui perivallontos
    public albumclient(){
        //dhmiourgia parathyrou kai megethous ths efarmoghs

        JFrame frame = new JFrame("Album manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 450);
        frame.setLayout(new BorderLayout());
//dhmiourgia panelgia loabels kai textfields
JPanel panel = new JPanel(new GridLayout(6, 2));

// Δημιουργία των labels
JLabel lbltitlos=new JLabel("Title:");
JLabel lblperigrafh=new JLabel("Description:");
JLabel lbleidosmousikhs=new JLabel("Type:");
JLabel lblxronos=new JLabel("Year:");
JLabel lblepilegmenhmousikh=new JLabel("Select Song:");

// Προσθήκη labels και αντίστοιχων components στο panel
panel.add(lbltitlos);
panel.add(titlos);

panel.add(lblperigrafh);
panel.add(perigrafh);

panel.add(lbleidosmousikhs);
panel.add(eidos);

panel.add(lblxronos);
panel.add(etos);

panel.add(lblepilegmenhmousikh);
panel.add(epiloghtragoudiou);
//dhmiourgia koumpiwn kai prosthikh leitourgiwn
        JButton insert=new JButton("Insert");
                insert.addActionListener(this::eisagwghalbum);

        JButton enhmerwsh=new JButton("Update");
                enhmerwsh.addActionListener(this::ananewshstoixeiwnalbum);

        JButton delete=new JButton("Delete");       
        delete.addActionListener(this::diagrafhalbum);
      
        
        
        JButton anazhthsh=new JButton("Search");

        anazhthsh.addActionListener(e -> searchalbumclient.main(new String[]{}));
//prosthikh neou panel gia ta koumpia
        JPanel panelbutton=new JPanel();
        panelbutton.add(insert);
        panelbutton.add(enhmerwsh);
        panelbutton.add(delete);
        panelbutton.add(anazhthsh);
//leitourgia klik se kapoio stoixeio toy pinaka ou thelei o xrhsths na dei ta stoixeia tou
        listaalbum.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                String selected = listaalbum.getSelectedValue();
                if (selected != null && albuminfo.containsKey(selected)) {
                    String[] details = albuminfo.get(selected);
                    titlos.setText(selected);
                    perigrafh.setText(details[0]);
                    eidos.setText(details[1]);
                    etos.setText(details[2]);
                    epiloghtragoudiou.setSelectedItem(details[3]);
                }
            }
        });
//prosthikh panel sto parathyro
        frame.add(panel, BorderLayout.NORTH);
        frame.add(new JScrollPane(listaalbum), BorderLayout.CENTER);
        frame.add(panelbutton, BorderLayout.SOUTH);
//emfanhsh parathyrou
        frame.setVisible(true);
        listatragoudiwnserver();
    }
//methodos eisagwghs stoixeiwn album
    private void eisagwghalbum(ActionEvent e) {
        String title=titlos.getText().trim();
        String description=perigrafh.getText().trim();
        String genre=eidos.getText().trim();
        String relyear=etos.getText().trim();
        String choosensong=(String)epiloghtragoudiou.getSelectedItem();
//elegxos an symplhrwthikan ta pedia
        if (title.isEmpty()||description.isEmpty()||genre.isEmpty()||relyear.isEmpty()||choosensong == null) {
            JOptionPane.showMessageDialog(null, "Fields must be written");
 
        }
//elegxos egkyrothtas xronologias
        int xronologia;
        try {
            xronologia=Integer.parseInt(relyear);
            //synthikh se periptwsh pou o client ypevalle arnhtikh xronologia
            if(xronologia<=0) {
                JOptionPane.showMessageDialog(null, " Year must be a positive number.");
               
            }
        }catch(NumberFormatException ex) {
            //sfalma se periptwsh mh  ypovolhs akeraiou arithmou
            JOptionPane.showMessageDialog(null, "year must be an integer number");
            return;
        }
//metavlhth pou dhmiourgei aithma ston server
        String request="ADD ALBUM:" + title + ":" + description + ":" + genre + ":" + xronologia + ":" + choosensong;
        //klhsh methodou pou stelnei aithma sto server
        aithma(request);
        //rosthikh album kai stoixeiwn tou sth domh
        albumlist.addElement(title);
        albuminfo.put(title, new String[]{description, genre, String.valueOf(xronologia), choosensong});
    }
//methodos ananewshs stoixeiwn album

private void ananewshstoixeiwnalbum(ActionEvent e) {
    //lhpsh album apo th lista
        String selected = listaalbum.getSelectedValue();
        if (selected == null) {
            JOptionPane.showMessageDialog(null, "Select an album to update.");
            return;
        }

        String title=titlos.getText().trim();
        String desc=perigrafh.getText().trim();
        String type=eidos.getText().trim();
        String xronologia=etos.getText().trim();
        String choosensong=(String) epiloghtragoudiou.getSelectedItem();

        // Έλεγχος αν όλα τα πεδία έχουν συμπληρωθεί
        if (title.isEmpty()||desc.isEmpty()||type.isEmpty()||xronologia.isEmpty()||choosensong== null) {
            JOptionPane.showMessageDialog(null, "All fields must be filled out.");
            return;
        }

        
        //elegxos egkyrothtas etous
        int relyear;
        try {
            //metatroph keimenou se akeraio arithmo
            relyear=Integer.parseInt(xronologia);
            //elegxos oti h xronologia thetikos arithmos
            if (relyear<=0) {
                JOptionPane.showMessageDialog(null, " Year must be a positive number.");
                return;
            }
        }catch(NumberFormatException ex) {
            //ektypwsh mhnymatos se periptwsh pou h ypovolh etous htan diaforetiko tou arithmou
            JOptionPane.showMessageDialog(null, "Year must be a number.");
            return;
        }

        //dhmiourgia kai apostolh aithmatos gia ton server server
        String request="UPDATE ALBUM:"+selected+":"+ title+":"+desc+ ":"+type+":"+relyear+":"+choosensong;
        aithma(request);

      
        //enhmerwsh gia ta nea stoixeia
        // enhmerwsh an o titlos allaxe
        albuminfo.put(title, new String[]{desc,type,String.valueOf(relyear),choosensong});
        if (!selected.equals(title)) {
            albumlist.removeElement(selected);
            albumlist.addElement(title);
        }
    }
    
//methodos diagrafhs stoixeiwn album

    private void diagrafhalbum(ActionEvent e){
        //metavlhth pou deixnei thn epilgmeno album
        String selected=listaalbum.getSelectedValue();
       //synthikh  efoson yparxei epilogh albun 
        if(selected!=null){
            aithma("DELETE ALBUM:" + selected);
            //diagrafh album kai stoixeiwn toy apo th domh
            albumlist.removeElement(selected);
            albuminfo.remove(selected);
        }else{
            JOptionPane.showMessageDialog(null, "Select album to delete.");
        }
    }
//methodos gia th lhpsh tragoudiwn apo to server kai prosthikh sto combobox
    private void listatragoudiwnserver(){
        try (Socket socket=new Socket(address, port);
             ObjectOutputStream out=new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in=new ObjectInputStream(socket.getInputStream())) {
//apostoljh aithmatos sto server
            out.writeObject("GETSONGS");
            out.flush();
//anagnwsh apanthshs tou server apo ton client
            Object response=in.readObject();
            if (response instanceof List<?>){
                List<?>songs=(List<?>)response;
                epiloghtragoudiou.removeAllItems();
                for(Object song:songs){
                    epiloghtragoudiou.addItem(song.toString());
                }
            }
        } catch(IOException | ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "error loading songs: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }
//methodos opou diaxeirizetai thn epikoinwnia me ton server me socket

    private void aithma(String request) {
        try (Socket socket=new Socket(address, port);
             ObjectOutputStream out=new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in=new ObjectInputStream(socket.getInputStream())) {
//apostolh aithmatos
            out.writeObject(request);
            out.flush();
//metanlhth gia thn anagnwsh kai emfanhsh apanthshs apo server
            String response=(String)in.readObject();
            JOptionPane.showMessageDialog(null,response);

        }catch(IOException|ClassNotFoundException ex){
//sfalma se periptwsh adynamias anagnwshs aithmatos tou client pros ton server
            JOptionPane.showMessageDialog(null, "Error in communication " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
