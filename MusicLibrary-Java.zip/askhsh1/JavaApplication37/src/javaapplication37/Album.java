/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication37;

/**
 *
 * @author zoroz
 */
//icsd22077
//Zacharias Kokkinakis

import java.util.Collections;
import java.util.List;
import java.util.Objects;
//dhmiourgia immutable klashs
public class Album {
    
    //stoixeia tou album
    private final String titlos;
    private final String eidos;
    private final int xronos;
    private final List<Song> songs; // Χρήση της Song
//dhmiourgia constructor opou kaleitai gia thn dhmiourgia dedomenwn
    Album(String titlos, String eidos, int xronos, List<Song> songs) {
        this.titlos = titlos;
        this.eidos = eidos;
        if (xronos < 0) {
            System.out.println("Release year cannot be negative");
        }
        this.xronos = xronos;
        this.songs = Collections.unmodifiableList(songs); // Immutable list
    }
//getters methodoi 
    String gettitle() {
        return titlos;
    }

    String geteidosmousikis() {
        return eidos;
    }

    int getxronos() {
        return xronos;
    }

    List<Song> getsongs() {
        return Collections.unmodifiableList(songs);
    }
//methodos toString
    @Override
    public String toString() {
        return String.format("Album: %s (%d) \n Genre: %s \nSongs:%s \n", titlos, xronos, eidos);
    }
}
