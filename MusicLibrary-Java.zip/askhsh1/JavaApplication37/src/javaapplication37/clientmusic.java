//icsd22077
//Zacharias Kokkinakis

package javaapplication37;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import java.util.HashMap;

public class clientmusic{
    private static final String address = "127.0.0.1";
    private static final int port = 888;
//lista gia ta tragoudia kai map gia tis leptomeries tous
    private DefaultListModel<String> listatragoudiwn = new DefaultListModel<>();
    private HashMap<String, String[]> songdetails = new HashMap<>();
//pedia dhlwshs tou tragoudiou
    private JList<String> songlist = new JList<>(listatragoudiwn);
    private JTextField titlos = new JTextField();
    private JTextField kallitexnhs = new JTextField();
    private JTextField diarkeia = new JTextField();

    public static void main(String[] args) {
        //ekkinhsh efarmoghs me swing
        SwingUtilities.invokeLater(clientmusic::new);
    }

    public clientmusic() {
                //parathyro kai diastaseis ths ths efarmoghs
        JFrame frame = new JFrame("Music management");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 350);
        frame.setLayout(new BorderLayout());

        JPanel pinakas = new JPanel(new GridLayout(4, 2));
   //onomasia twn labels
JLabel lbl1 = new JLabel("Title:");
JLabel lbl2 = new JLabel("Artist:");
JLabel lbl3 = new JLabel("Duration:");
//pinakas gia ta pedia eisagwghs
pinakas.add(lbl1);
pinakas.add(titlos);
pinakas.add(lbl2);
pinakas.add(kallitexnhs);
pinakas.add(lbl3);
pinakas.add(diarkeia);
//dhmiourgia twn koumpiwn sto gui periballon
        JButton eisagwgh = new JButton("Insert");
        JButton ananewshstoixeiewn = new JButton("Update");
        JButton diagrafhstoixeiwn = new JButton("Delete");
//prosthiki ksexwristou panel gia ta koumpia
        JPanel pinakas2 = new JPanel();
        //klhsh methodwn otan kanei klik o xrhsths se kapoio koumpi 
        eisagwgh.addActionListener(this::eisagwgh);
        
        ananewshstoixeiewn.addActionListener(this::ananewsh);
        
        diagrafhstoixeiwn.addActionListener(this::diagrafh);

        
        pinakas2.add(eisagwgh);
        
        pinakas2.add(ananewshstoixeiewn);
        pinakas2.add(diagrafhstoixeiwn);
//leitourgia pou epitrepei thn provolh stoixeiwn tou tragoudiou
        songlist.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                String selected = songlist.getSelectedValue();
                if (selected!=null && songdetails.containsKey(selected)) {
                    String[] details = songdetails.get(selected);
                    titlos.setText(selected);
                    kallitexnhs.setText(details[0]);
                    diarkeia.setText(details[1]);
                }
            }
        });

        frame.add(pinakas, BorderLayout.NORTH);
        frame.add(new JScrollPane(songlist), BorderLayout.CENTER);
        frame.add(pinakas2, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
//methodos pou eisagei o xrhsths ta stoixeia tou album
    private void eisagwgh(ActionEvent e) {
        String title=titlos.getText().trim();
        String artist=kallitexnhs.getText().trim();
        String dur=diarkeia.getText().trim();
//synthikh pou elegxei an symplhrwthikan ola ta pedia
        if (title.isEmpty()||artist.isEmpty()||dur.isEmpty()) {
            JOptionPane.showMessageDialog(null, "all fields must be completed");
            return;
        }
//synthikh pou elegxei an o xronos tragoudiou pou ypevale o xrhsths einai megalyteros tou 0
        int duration;
        try {
            //metavlhth pou prosdiorizei thn diarkeia gia thn apothikefsh sth domh
            duration =Integer.parseInt(dur);
            if (duration <= 0) {
                JOptionPane.showMessageDialog(null, "number must be >0");
                return;
            }
        } catch (NumberFormatException ex) {
            //sfalma se periptwsh pou o xrhsths ypovallei otidhpote diaforetiko ektos arithmou
            JOptionPane.showMessageDialog(null, "it is not a number.");
            return;
        }
//metavlhtes pou dhmiourgoun to aithma gia prosthikh neou tragoudiou me monadiko titlo
        String request = "ADD SONG:" + title + ":" + artist + ":" + duration;
        String response=elegxossyndeshs(request);
////an to tragoudi exei monadiko titlo tote prostithetai sth domh tou client
        if (!response.contains("music exists!")) {
            //prosthiki titlou kai twn ypoloipwn stoixeiwn sth domh
            listatragoudiwn.addElement(title);
            songdetails.put(title, new String[]{artist, String.valueOf(duration)});
        }
    }
//methodos pou ananewnei hdh yparxonta stoixeia
    private void ananewsh(ActionEvent e) {
        String selected = songlist.getSelectedValue();
        if (selected != null) {
            //times pou prosdiorizoun ta pedia pou ananewnnei o xrhsths
            String neostitlos = titlos.getText().trim();
            String neosartist = kallitexnhs.getText().trim();
            String neadiarkeia = diarkeia.getText().trim();
//elegxos an den exoun symplhrwthei ola ta pedia
            if (neostitlos.isEmpty() || neosartist.isEmpty() || neadiarkeia.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields must be filled out.");
                return;
            }
//apostolh aithmatos gia ananewsh pediwn
            elegxossyndeshs("UPDATE SONG:"+selected+":"+neostitlos);
//apothikefsh n ewn stoixeiwn sta pedia
            listatragoudiwn.set(songlist.getSelectedIndex(), neostitlos);
            songdetails.remove(selected);
            songdetails.put(neostitlos, new String[]{neosartist, neadiarkeia});
        } else {
            JOptionPane.showMessageDialog(null, "Select a song to update.");
        }
    }
//methodos diagrafhs stoixeiwn enos album
    private void diagrafh(ActionEvent e) {
//metavlhth pou prosdiorizei thn epilogh mousikhs pou thelei na diagrapsei o xrhsths
        String choice = songlist.getSelectedValue();
        //synthikh na exei epilexei ena tragoudi o xrhsths
        if (choice!=null) {
            //metafora aithmatos sto server
            elegxossyndeshs("DELETE SONG:"+choice);
            listatragoudiwn.removeElement(choice);
            songdetails.remove(choice);
        } else 
            //synthikh se periptwsh pou den epilxei kapoia mousikh o xrhsths na diagrapsei enw pathse tou koumpi diagrafh
        {
            
            JOptionPane.showMessageDialog(null, "Select a song to delete.");
        }
    }
//methodos opou diaxeirizetai thn epikoinwnia me ton server me socket
    private String elegxossyndeshs(String request) {
        //prospatheia syndeshs me ton server
        try (Socket socket=new Socket(address, port);
             //dhmiourgia rohs exodou gia apostolh dedomenwn ston server
                ObjectOutputStream out=new ObjectOutputStream(socket.getOutputStream());
           //dhmiourgia eisodou gia lhpsh apanthshs apo ton server
                ObjectInputStream in=new ObjectInputStream(socket.getInputStream())) {
//apostolh aithmatos ston server
            out.writeObject(request);
            out.flush();
//anagnwsh apanthshs me server
            String response=(String) in.readObject();
            JOptionPane.showMessageDialog(null,response);
            return response;

        }//synthikh se periptwsh opou yparxei provlhma sthn epikoinwnia me server
        catch (IOException|ClassNotFoundException ex){
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
            return "Error";
        }
    }
} 