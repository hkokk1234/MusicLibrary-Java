//icsd22077
//Zacharias Kokkinakis


package javaapplication37;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.*;
import java.net.Socket;

public class searchalbumclient {
    //diefthinsi kai port pou trexei o server
    private static final String address="127.0.0.1";
    private static final int port=888;

    public static void main(String[] args) {
        //parathyro kai diastaseis ths ths efarmoghs
        JFrame frame = new JFrame("Search album");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new BorderLayout());
//dhmiourgia panel anazhthshs
        JPanel pinakasanazhthshs=new JPanel(new BorderLayout());
        //pedio gia anazthshs kai kathorismos diastasewn
        JTextField pedioanazthshs=new JTextField();
                pinakasanazhthshs.add(pedioanazthshs, BorderLayout.CENTER);

       //koumpi anazhthshs 
        JButton koumpianazhthshs=new JButton("Search");
        //dhmiourgia listwn pou prosdiorizoun ta apotelesmata anazhthshs kai thn litsa twn apotelesmatwn
        DefaultListModel<String> apotelesmata=new DefaultListModel<>();
        JList<String> listaapotelesmatwn=new JList<>(apotelesmata);
//label , components sto panel kai kathorismos diastasewn tou pinaka anazhthshs
        pinakasanazhthshs.add(new JLabel("type title:"), BorderLayout.NORTH);
        pinakasanazhthshs.add(koumpianazhthshs, BorderLayout.EAST);

        frame.add(pinakasanazhthshs, BorderLayout.NORTH);
        frame.add(new JScrollPane(listaapotelesmatwn), BorderLayout.CENTER);
//leitourgia koumpiou anazhthshs
        koumpianazhthshs.addActionListener((ActionEvent e)->{
            //metavlhth pou lambanei ton titlo apo to pedio anazhthshs
            String title=pedioanazthshs.getText().trim();
            //diagrafh yparxoun sth lista apotelesmatwn anazhthshs apotelesmatwn
            apotelesmata.clear();
            if (!title.isEmpty()){
                //metavlhth pou prosdiorizei metafora aithmatos ston server
                String response=aithmastonserver("SEARCH ALBUM: "+title+" ");
                //apanthsh tou server sth lista
                apotelesmata.addElement(" "+response+" "); 
                
            }else{
                //mhnyma se periptwsh pou to pedio anazhthshs einai adeio
                JOptionPane.showMessageDialog(frame, "please enter a title.");
            }
        });

        frame.setVisible(true);
    }
//methodos apostolhs aithmatos sto server kai lhpsh apanthsewn
    private static String aithmastonserver(String request) {
        try (Socket socket = new Socket(address, port);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {
//apostolh aithmatos ston server
            out.writeObject(request);
            out.flush();
//epistrofh apanthshs ston server
            return (String) in.readObject();

        } catch (IOException | ClassNotFoundException ex) {
            //sfalma kata th diarkeia apostolhs mhnymatos
            return "Error: " + ex.getMessage();
        }
    }
}
