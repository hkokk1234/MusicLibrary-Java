/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication37;

/**
 *
 * @author zoroz
 */
//icsd22077
//Zacharias Kokkinakis


import java.util.Objects;
//immutable klash mousikhs
class Song {
    //metavlhtes pou prosdiorizoun ta stoixea tou album
    private final String titlosmusic;
    private final String kallitexnhs;
    private final int xronos;
//constructor opou dhlwnontai ta pedia
    Song(String titlosmusic, String kallitexnhs, int xronos) {
        this.titlosmusic = titlosmusic;
        this.kallitexnhs =kallitexnhs;
        if(xronos < 0) {
         System.out.println("Duration cannot be negative");
        }
        this.xronos=xronos;
    }
//getters methodoi
    String gettitlos() {
        return titlosmusic;
    }

    String getkallitexnhs() {
        return kallitexnhs;
    }

    int getxronos() {
        return xronos;
    }

    //methodos tostring
    @Override
    public String toString() {
        return String.format("%title:s\n artist:%s\n year:%d", titlosmusic, kallitexnhs, xronos);
    }
}
